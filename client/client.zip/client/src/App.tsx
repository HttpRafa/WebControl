import React, {createContext, useState} from "react";

import JavaScriptTags from './components/script/JavaScriptTags';
import AppRoot from "./components/AppRoot";

const SiteIdContext = createContext(-100)
const HideNavIdContext = createContext([])
const ApplicationStateContext = createContext(undefined)
const ConsoleMessagesContext = createContext(["Loading Console..."])
const ErrorCallbackContext = createContext(function () {})

function App() {

  const [sideId, setSideId] = useState(-100)
  const [hideNavId, sethideNavId] = useState([])
  const [applicationState, setApplicationState] = useState(undefined)
  const [consoleMessages, setConsoleMessages] = useState(["Loading Console..."])

  return (
      <>
        <SiteIdContext.Provider value={sideId}>
          <ApplicationStateContext.Provider value={applicationState}>
            <ConsoleMessagesContext.Provider value={consoleMessages}>
              <HideNavIdContext.Provider value={hideNavId}>
                <ErrorCallbackContext.Provider value={function () {

                }}>
                  <AppRoot submitLogin={function () {

                  }} connectNode={function () {

                  }} setSideId={setSideId}/>
                </ErrorCallbackContext.Provider>
              </HideNavIdContext.Provider>
            </ConsoleMessagesContext.Provider>
          </ApplicationStateContext.Provider>
        </SiteIdContext.Provider>
        <JavaScriptTags />
      </>
  );
}

export default App;