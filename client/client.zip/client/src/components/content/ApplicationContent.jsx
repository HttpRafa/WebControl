import TopNavigation from '../sidebar/TopNavigation';
import ApplicationStats from '../server/ApplicationStats';

const ApplicationContent = () => {
    return (
        <div className='content-container'>
            <TopNavigation title={"Application"}/>
            <ApplicationStats />
        </div>
    );
};

export default ApplicationContent;
