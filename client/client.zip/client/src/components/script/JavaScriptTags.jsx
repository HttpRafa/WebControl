const JavaScriptTags = () => {
    return (
        <>
        </>
    );
}

export default JavaScriptTags;