import React, {createContext, useContext} from "react";

import SideBar from "./sidebar/SideBar";
import HomeContent from "./content/HomeContent";
import ApplicationContent from "./content/ApplicationContent";
import OptionsContent from "./content/OptionsContent";
import ConsoleContent from "./content/ConsoleContent";
import FilesContent from "./content/FilesContent";
import AccessContent from "./content/AccessContent";
import ConnectNodeContent from "./content/pre/ConnectNodeContent";
import LoginContent from "./content/pre/LoginContent";
import CreateAccountContent from "./content/pre/CreateAccountContent";
import LoadingContent from "./content/pre/LoadingContent";

const SiteIdContext = createContext(-100)

const AppRoot = ( { submitLogin, connectNode, setSideId } ) => {

    // eslint-disable-next-line no-undef
    const siteId = useContext(SiteIdContext);
    // eslint-disable-next-line no-undef
    const hideNavId = useContext(HideNavIdContext);

    let content;

    if(siteId === -1) {
        content = <HomeContent />;
    } else if(siteId === -2) {
        content = <ApplicationContent/>;
    } else if(siteId === -3) {
        content = <OptionsContent />;
    } else if(siteId === -4) {
        content = <ConsoleContent clickSend={function () {
        }}/>;
    } else if(siteId === -5) {
        content = <FilesContent />;
    } else if(siteId === -6) {
        content = <AccessContent />;
    } else if(siteId === -100) {
        content = <LoadingContent />;
    } else if(siteId === -101) {
        content = <ConnectNodeContent submitNode={connectNode} />;
    } else if(siteId === -102) {
        content = <LoginContent submitLogin={submitLogin} />;
    } else if(siteId === -103) {
        content = <CreateAccountContent />;
    }

    return (
        <div className="flex">
            <SideBar hideSideBar={hideNavId} iconClickCallback={function (callbackSiteId) {
                setSideId(callbackSiteId);
            }}/>
            {content}
        </div>
    );
}

export default AppRoot;